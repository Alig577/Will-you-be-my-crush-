# Anti-rejectionProposalPrank.github.io
You can't say no to this proposal.                                                                                                                                       

Visit link here: https://andrejarl.github.io/Anti-rejectionProposalPrank.github.io/proposal.html
# Website Preview 
![image](https://user-images.githubusercontent.com/104331025/233835094-89883a1e-d881-485f-933d-53adf6f938c4.png)
